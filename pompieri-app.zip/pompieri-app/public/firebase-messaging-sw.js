importScripts('https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.12.2/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: "AIzaSyBT1N9IQP4abh7y51KoX51UbxaQh-p4dPs",
  authDomain: "psicontrol-ada7c.firebaseapp.com",
  projectId: "psicontrol-ada7c",
  storageBucket: "psicontrol-ada7c.firebasestorage.app",
  messagingSenderId: "1095291613627",
  appId: "1:1095291613627:web:8dbccbd484578c0968149e"
});

const messaging = firebase.messaging();

// Notificare primită când app-ul e în fundal / închis
messaging.onBackgroundMessage((payload) => {
  console.log('[SW] Mesaj primit în fundal:', payload);

  const data = payload.data || {};
  const title = data.title || '🚨 ALERTĂ INCENDIU';
  const options = {
    body: data.body || `Locație: ${data.locatie || 'necunoscută'}`,
    icon: '/icon-192.png',
    badge: '/icon-192.png',
    tag: 'incendiu-alerta',
    requireInteraction: true,
    vibrate: [500, 200, 500, 200, 500, 200, 500],
    data: {
      url: '/pompier.html?simulareId=' + (data.simulareId || ''),
      locatie: data.locatie || '',
      simulareId: data.simulareId || ''
    }
  };

  self.registration.showNotification(title, options);
});

// Click pe notificare -> deschide pagina de alarmă
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = event.notification.data?.url || '/pompier.html';

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if (client.url.includes('pompier.html') && 'focus' in client) {
          client.navigate(url);
          return client.focus();
        }
      }
      if (clients.openWindow) {
        return clients.openWindow(url);
      }
    })
  );
});
