// Configurația Firebase - publică, generată din Firebase Console
const firebaseConfig = {
  apiKey: "AIzaSyBT1N9IQP4abh7y51KoX51UbxaQh-p4dPs",
  authDomain: "psicontrol-ada7c.firebaseapp.com",
  projectId: "psicontrol-ada7c",
  storageBucket: "psicontrol-ada7c.firebasestorage.app",
  messagingSenderId: "1095291613627",
  appId: "1:1095291613627:web:8dbccbd484578c0968149e",
  measurementId: "G-WF76XNDQQZ"
};

const VAPID_KEY = "BLPeR9FlnEirGmcVjOGk9O9OXqP6ukE4uKuRry7T5n1C6MmdUUgOObVIvKdJhz7BXIQkOIri66zyNOJm5KYeRCl";
