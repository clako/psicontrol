// server.js
// Server local care trimite notificări push către pompieri prin Firebase Cloud Messaging.
// Rulează pe PC-ul tău. Trebuie pornit înainte să declanșezi o simulare din admin panel.

const express = require('express');
const cors = require('cors');
const admin = require('firebase-admin');

// ----------------------------------------------------------------------------
// IMPORTANT: pune fișierul JSON descărcat din Firebase (Service Account)
// în același folder cu acest server.js și redenumește-l "serviceAccountKey.json"
// NU urca niciodată acest fișier pe GitHub / nu-l trimite nimănui!
// ----------------------------------------------------------------------------
const serviceAccount = require('./serviceAccountKey.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

const db = admin.firestore();
const app = express();
app.use(cors());
app.use(express.json());

const PORT = 3001;

app.post('/declanseaza', async (req, res) => {
  const { simulareId, locatie, echipa } = req.body;
  console.log(`\n🔥 Simulare declanșată: "${locatie}" | Echipă: ${echipa} | ID: ${simulareId}`);

  try {
    // Ia toți pompierii activi (sau doar echipa selectată)
    let query = db.collection('pompieri').where('activ', '==', true);
    if (echipa && echipa !== 'toate') {
      query = query.where('echipa', '==', echipa);
    }

    const snapshot = await query.get();

    if (snapshot.empty) {
      console.log('⚠️  Niciun pompier găsit pentru notificare.');
      return res.json({ success: true, trimise: 0, mesaj: 'Niciun pompier de notificat.' });
    }

    const tokens = [];
    snapshot.forEach(doc => {
      const data = doc.data();
      if (data.fcmToken) tokens.push(data.fcmToken);
    });

    console.log(`📲 Trimit notificări către ${tokens.length} pompieri...`);

    const message = {
      data: {
        title: '🚨 ALERTĂ INCENDIU - SIMULARE',
        body: `Locație: ${locatie}`,
        locatie: locatie,
        simulareId: simulareId
      },
      tokens: tokens
    };

    const response = await admin.messaging().sendEachForMulticast(message);

    console.log(`✅ Trimise cu succes: ${response.successCount}`);
    if (response.failureCount > 0) {
      console.log(`❌ Eșuate: ${response.failureCount}`);
      response.responses.forEach((r, i) => {
        if (!r.success) console.log(`   - Token ${i}: ${r.error.message}`);
      });
    }

    res.json({
      success: true,
      trimise: response.successCount,
      esuate: response.failureCount
    });

  } catch (err) {
    console.error('❌ Eroare la trimiterea notificărilor:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/', (req, res) => {
  res.send('Server notificări pompieri — funcționează ✅');
});

app.listen(PORT, () => {
  console.log(`\n🚒 Server de notificări pornit pe http://localhost:${PORT}`);
  console.log(`   Lasă această fereastră deschisă cât timp vrei să poți declanșa simulări.\n`);
});
