# 🚒 Aplicație Simulare Incendiu — Ghid de Instalare

## Ce conține acest proiect

```
pompieri-app/
├── public/
│   ├── index.html              ← Panou Admin (deschis pe PC, în browser)
│   ├── pompier.html            ← Aplicația pentru pompieri (PWA, pe telefon)
│   ├── firebase-config.js      ← Configurația Firebase (publică)
│   ├── firebase-messaging-sw.js← Service Worker (notificări în fundal)
│   ├── manifest.json           ← Manifest PWA
│   ├── icon-192.png / icon-512.png
├── server.js                   ← Server Node.js (trimite notificările)
├── package.json
└── serviceAccountKey.json      ← TU TREBUIE SĂ-L ADAUGI (secret, NU se distribuie)
```

---

## PASUL 1 — Instalează Node.js (dacă nu îl ai)

Descarcă de pe https://nodejs.org (versiunea LTS) și instalează normal (Next, Next, Finish).

Verifică instalarea, deschide **Command Prompt** și scrie:
```
node --version
```
Trebuie să apară ceva gen `v20.x.x`.

---

## PASUL 2 — Pune cheia secretă Firebase la locul ei

1. Redenumește fișierul JSON pe care l-ai descărcat din Firebase (Service Account) în:
   ```
   serviceAccountKey.json
   ```
2. Pune-l în folderul rădăcină al proiectului (`pompieri-app/`), lângă `server.js`.

⚠️ **Acest fișier e secret!** Nu-l trimite nimănui, nu-l urca pe GitHub.

---

## PASUL 3 — Instalează dependențele serverului

În folderul `pompieri-app/`, deschide Command Prompt acolo (Shift + Click dreapta → "Open PowerShell window here") și rulează:

```
npm install
```

Așteaptă să se termine (durează 1-2 minute).

---

## PASUL 4 — Pornește serverul de notificări

```
npm start
```

Ar trebui să vezi:
```
🚒 Server de notificări pornit pe http://localhost:3001
```

**Lasă această fereastră deschisă** cât timp vrei să poți declanșa simulări. Dacă o închizi, notificările nu se mai trimit.

---

## PASUL 5 — Deschide Panoul Admin

În folderul `public/`, ai nevoie ca fișierele să fie servite printr-un mic server web local (nu poți deschide direct `index.html` din Explorer, pentru că Firebase + Service Worker necesită `http://`).

Cea mai simplă variantă — folosește pachetul `serve`:

```
npx serve public -p 8080
```

Apoi deschide în browser:
```
http://localhost:8080
```

Acesta e **Panoul Admin**.

---

## PASUL 6 — Pompierii instalează aplicația pe telefon

Telefoanele pompierilor trebuie să poată accesa acest server. Cele 2 opțiuni:

### Opțiunea A — Rețea locală (telefoane pe același WiFi cu PC-ul)
1. Află IP-ul local al PC-ului: în Command Prompt scrie `ipconfig`, caută "IPv4 Address" (ex: `192.168.1.50`)
2. Pe telefon, în browser, accesează: `http://192.168.1.50:8080/pompier.html`
3. ⚠️ Notă: Notificările push (FCM) prin `http://` (nesecurizat) **pot fi blocate de browser pe telefon**. Pentru funcționare completă, ai nevoie de HTTPS (vezi Opțiunea B).

### Opțiunea B — Recomandat: Firebase Hosting (gratuit, are HTTPS automat)
Asta rezolvă toate problemele de securitate și funcționează de oriunde (4G inclusiv):

```
npm install -g firebase-tools
firebase login
firebase init hosting
```
La întrebări răspunde:
- "What do you want to use as your public directory?" → `public`
- "Configure as single-page app?" → `No`

Apoi:
```
firebase deploy
```

Vei primi un link de tipul:
```
https://psicontrol-ada7c.web.app
```

Acesta e linkul pe care îl trimiți pompierilor (pentru `pompier.html`) și pe care îl folosești tu pentru admin (`index.html`).
Pompierii accesează: `https://psicontrol-ada7c.web.app/pompier.html` și apasă **"Adaugă pe ecranul principal"** din meniul browserului — devine ca o aplicație instalată.

---

## PASUL 7 — Testează

1. Pe telefon, deschide `pompier.html`, completează numele și echipa, apasă **"Activează notificările"** → acceptă permisiunea de notificări
2. Apasă **"🔔 Test notificare"** — ar trebui să vezi imediat ecranul roșu cu sunet
3. Din admin (`index.html`), alege o locație și apasă **"🔥 Declanșează Alarma"**
4. Telefonul pompierului ar trebui să primească alerta în câteva secunde, chiar dacă telefonul e blocat

---

## Probleme frecvente

**"Serverul local nu răspunde"** → verifică dacă fereastra cu `npm start` e încă deschisă și arată `localhost:3001`

**Pompierul nu primește notificarea când telefonul e blocat** → trebuie folosit HTTPS (Opțiunea B, Firebase Hosting), nu `http://`

**"Permission denied" la notificări pe telefon** → verifică Setări telefon → Aplicații → Browser → Notificări → activat

---

## Cum funcționează pe scurt

1. Pompierul se înregistrează în `pompier.html` → primește un **FCM token** unic, salvat în Firestore
2. Adminul declanșează o simulare din `index.html` → se salvează în Firestore + cere serverului local (`server.js`) să trimită notificări
3. `server.js` ia toate token-urile pompierilor relevanți și trimite notificare prin Firebase Cloud Messaging
4. Telefonul pompierului primește notificarea (chiar dacă e blocat) → deschide `pompier.html` → ecran roșu + sunet 30 secunde
5. Pompierul confirmă prezența → adminul vede în timp real cine a confirmat și în cât timp
